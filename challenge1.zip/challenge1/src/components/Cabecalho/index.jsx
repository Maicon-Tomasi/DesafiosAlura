import styled from 'styled-components';
import Logo from './logoAlura.png';
import Search from 'antd/es/transfer/search';
import AvatarComponent from '../Avatar';



const HeaderEstilizado = styled.header`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 10px;
`;

const ImgEstilizada = styled.img`
  width: 100%;
  max-width: 200px;
`;

const DivInputPesquisa = styled.div`
  width: 100%;
  max-width: 800px;
`;

const SearchEstilizado = styled.input`
     width: 100%;
     background-color: #FFFFFF29;
     border: none;
     border-radius: 8px;
     color: white;
     padding: 20px;
     outline: none;
`;

const Cabecalho = () => {
  return (
    <HeaderEstilizado>
      <ImgEstilizada src={Logo} />

      <DivInputPesquisa>
        <SearchEstilizado type='text' placeholder='Busque por algo' />
      </DivInputPesquisa>

      <AvatarComponent />

    </HeaderEstilizado>
  );
};

export default Cabecalho;
