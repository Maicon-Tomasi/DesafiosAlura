import { useContext } from "react"
import styled from "styled-components"
import { TrocaCorContext } from "../../context/TrocaCorContext"
import { CriarCardComunidadeContext } from "../../context/CriaCardComunidadeContext"

const ContainerFormulario = styled.div`
     width: 100%;
     padding: 0 40px;
     color: white;
     font-weight: 400;
`

const FormEstilziado = styled.form`
     display: flex;
     flex-direction: column;
`

const InputEstilizado = styled.input`
     width: 100%;
     max-width: 300px;
     height: 56px;
     padding: 0 5px;
     background-color: #FFFFFF29;
     color: Neutral/$white;
     border-radius: 8px;
     border: none;
     margin-bottom: 15px;
     outline: none;
`

const TextareaEstilizado = styled.textarea`
     resize: vertical;
     width: 100%;
     max-width: 300px;
     height: 56px;
     padding: 10px 5px;
     background-color: #FFFFFF29;
     color: Neutral/$white;
     border-radius: 8px;
     border: none;
     outline: none;
`

const SelectEstilizado = styled.select`
     width: 100%;
     max-width: 300px;
     height: 56px;
     padding: 0 5px;
     color: #ffffff;
     background-color: #FFFFFF29;
     border-radius: 8px;
     border: none;
     margin-bottom: 15px;
     outline: none;

     option{
          color: black;
     }
`

const InputColorEstilizado = styled.input`
     width: 100%;
     max-width: 300px;
     height: 56px;
     background: none;
     border: 1px solid white;
     border-radius: 8px;
`

const BotaoEstilizado = styled.button`
     width: 100%;
     max-width: 300px;
     height: 56px;
     margin-top: 10px;
     border-radius: 8px;
     border: none;
     background-color: #5081FB;
     color: white;
     cursor: pointer;
     transition: background-color 0.2s ease, transform 0.2s ease;

     &:active {
     background-color: #406ace; /* Cor mais escura ao clicar */
     transform: scale(0.98); /* Efeito de compressão do botão */
     }
`

const FormProjeto = () => {

     const {cor, trocaCor} = useContext(TrocaCorContext);
     const {setTitulo, setDescricao, setLinguagem, postarCodigo} = useContext(CriarCardComunidadeContext);

     const handleColorChange = (e) => {
          trocaCor(e.target.value); 
        };

     const handleTituloChange = (e) => {
          setTitulo(e.target.value);
     };
      
     const handleDescricaoChange = (e) => {
          setDescricao(e.target.value);
     };

     const handleLinguagemChange = (e) => {
          setLinguagem(e.target.value);
     };
     
     const EnviaCodigo = (e)=> {
          e.preventDefault()
          postarCodigo()
     }

     return(
          <ContainerFormulario>
               <p>Seu projeto</p>

               <FormEstilziado>
                    <InputEstilizado onChange={handleTituloChange} type="text" placeholder="Nome do seu projeto" />
                    <TextareaEstilizado onChange={handleDescricaoChange} placeholder="Decrição do seu projeto"></TextareaEstilizado>

                    <p>Linguagem / Personalização</p>

                    <SelectEstilizado onChange={handleLinguagemChange}>
                         <option value=""></option>
                         <option value="JavaScript">javaScript</option>
                         <option value="C#">C#</option>
                         <option value="Java">Java</option>
                         <option value="Php">PHP</option>
                    </SelectEstilizado>
                    <InputColorEstilizado value={cor} type="color" onChange={handleColorChange}/>

                    <BotaoEstilizado type="submit" onClick={EnviaCodigo}>Salvar Projeto</BotaoEstilizado>
               </FormEstilziado>

          </ContainerFormulario>
     )

}
export default FormProjeto