import DescricaoCard from "../DescricaoCard"
import CodeEditor from "../EditorDeCodigo"


const CardComunidade = ({titulo, descricao, codigo}) =>{

     return(
          <div>
               <CodeEditor codigoComunidade={codigo} comunidade={true}/>
               <DescricaoCard titulo={titulo} descricao={descricao} />
          </div>

     )

}

export default CardComunidade