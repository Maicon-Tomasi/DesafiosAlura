import BtnHighlight from "../../components/BtnHighlight"
import CodeEditor from "../../components/EditorDeCodigo"
import FormProjeto from "../../components/FormProjeto"
import { TrocaCorProvider } from "../../context/TrocaCorContext"

const Editor = () => {

     return(
          <section style={{display: 'flex', justifyContent: 'center', marginTop: '30px'}}>
               
                    <div style={{display: 'flex', flexDirection: 'column'}}>
                         <CodeEditor  />
                         <BtnHighlight />
                    </div>
                    <div>
                         <FormProjeto />  
                    </div>

          </section>
     )
}

export default Editor